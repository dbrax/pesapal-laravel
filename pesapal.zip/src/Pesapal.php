<?php

namespace Epmnzava\Pesapal;

class Pesapal
{
    // Build your next great package.
}
